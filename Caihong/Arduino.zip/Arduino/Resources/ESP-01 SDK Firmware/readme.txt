boot_v1.2+.bin or boot_v1.5.bin              0x00000
user1.1024.new.2.bin                         0x01000
esp_init_data_default.bin                    0xfc000 (optional)
blank.bin                                    0x7e000 & 0xfe000
